@echo off
"%~dp0SHARP PC Server.exe" --forget-folders %*
