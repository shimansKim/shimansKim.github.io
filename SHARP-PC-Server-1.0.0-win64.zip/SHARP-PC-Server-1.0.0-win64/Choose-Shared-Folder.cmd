@echo off
"%~dp0SHARP PC Server.exe" --choose-folder %*
